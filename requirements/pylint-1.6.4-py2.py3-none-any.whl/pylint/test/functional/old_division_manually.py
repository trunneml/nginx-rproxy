from __future__ import division
print 1 / 3