"""This is gramatically correct, but it's still a SyntaxError"""
return # [return-outside-function]
